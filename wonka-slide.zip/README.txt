=== Plugin Name ===
Name: Wonka Slide
Contributors: llister, mrlister1
Donate link: https://paypal.me/Wonkasoft
Tags: slider, wonkasoft, featured images, images, shortcode, customizable
Requires at least: 3.0.1
Tested up to: 4.9.1
Requires PHP: 7.0+
Stable tag: 4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a shortcode slider that will make a slider out of the featured images from your blog posts.

== Description ==

Wonka Slide is a plugin that will let you quickly create a slider out of your featured images from your posts. Wonka Slide has the ability for slide count adjustment up to 10 slides.

== Installation ==

1. Upload `wonka-slide.zip` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `[wonka-slider]` in your page content or post content

== Frequently Asked Questions ==

= How do I use it? =

You can simple go to the Wonka Slide settings page and copy the shortcode so that you can paste it on the page that you would like it to display a slider on.

== Screenshots ==

1. /admin/img/wonka-slide-screen1.jpeg

== Changelog ==

*= 1.0 =*
*This is the first release of Wonka Slide.

== Upgrade Notice ==

*= 1.0 =*
*This is the first release of Wonka Slide this is the current version.

== Arbitrary section ==